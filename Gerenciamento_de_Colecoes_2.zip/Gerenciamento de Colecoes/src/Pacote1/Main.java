package Pacote1;

import javax.swing.*;


public class Main {

     public static JFrame janelaAtiva;

     public static void main(String[] args) {

         Thread novaT = new Thread(new Runnable() {
             @Override
             public void run() {

                SwingUtilities.invokeLater(Main::login);

             }
         });
         novaT.start();
    }

    private static void login(){
        Login janelaLOgin  = new Login();
        janelaAtiva = janelaLOgin.getLogin();
    }

    private static void painelControle(){
        janelaAtiva.dispose();
        JanelaControle janelaControle = new JanelaControle();
        janelaAtiva = janelaControle.janelaControle();
    }

    public void getConfirmaAcesso (String nome ){

        Thread novaT = new Thread(new Runnable() {
            @Override
            public void run() {
                janelaAtiva.dispose();
              SwingUtilities.invokeLater(Main::painelControle);
            }
        });
        novaT.start();

    }

}
//
