package Pacote1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class Adm extends AcoesFileCSV{


//--------------------------- Exclusiva para adm ----------------------------------

    private String novoAcesso ( String dadosNovoAcesso ) {
        return  setDadosFile( getFileAcessos() , dadosNovoAcesso ) ;
    }

    // criar função para editar , excluir user

    public String  setNovoAcesso( String novosDados ) {
        return novoAcesso( novosDados );
    }

    public boolean authAdm ( String user , String senha ) {

        String [][] consulta = getConteudoCompletoFile( getFileAcessos());

        for (int i = 0; i < consulta.length; i++) {
            if( user.equals(consulta[i][0]) && senha.equals( consulta[i][1])){
                System.out.println(consulta[i][0]+" --------- "+consulta[i][1]);
                return true ;
            }
        }
        return false ;
    }

//----------------------------  Colecionadores --------------------------------
    // ADM PD VER UM OU TODOS COLECIONADORES E ADD NOVEOS COLECIONADORES

    // vet colecionadores
    protected String [][] getColecinadores (  ) {
        try{
            String [][] consulta = getConteudoCompletoFile( getFileColecionadores() );
            return consulta ;
        }catch (Exception err){
            return new String[][] {{"Erro de formatação do arquivo "+err}};
        }
    }

    // ver UM colecionador
    protected String [][] getColecinadores ( String dados ) {
        try{
            String [][] consulta = getLinhasComIndex( getFileColecionadores() , dados);
            return consulta ;

        }catch (Exception err){
            return new String[][] {{"Erro de formatação do arquivo "+err}};
        }
    }

    // add colecionador
    protected   String setAddNovosColecionadores( String dados ){
        String retorno = setDadosFile( getFileColecionadores() , dados ) ;
        return retorno ;
    }


//-----------------------------------------------------------------------------



}
