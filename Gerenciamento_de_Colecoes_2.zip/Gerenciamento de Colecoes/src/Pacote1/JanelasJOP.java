package Pacote1;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class JanelasJOP extends Componentes {

    FuncaoGeral validador = new FuncaoGeral() ;

    private File imagemSelecionadaAdd = null;
    private String [] estadoTipo = {"Ruim", "Medio" ,"Bom" } ;
    private String [] categoriaTipo = {"Tenis", "Vestiario" ,"Figurinhas", "Coleções" , "Outros" } ;
    private String [] disponibilidade = {"Aceita troca","Nao aceita troca" } ;
    private LocalDateTime data = LocalDateTime.now();
    private DateTimeFormatter cod = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
    private DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd-MM-yyyy");

//===========================================================================================================================
// AQUI APLICAR VERIFICAÇÃO DE ID / CPF / CNPJ ja cadastrado

    public void novoColecionador (){

        Adm adm = new Adm();

        JPanel painel = setPainel(980 , 450 , null );
        painel.setLayout(null);
        //___________________________________________________________________________________

        JLabel l1 = posicaoTela(setFontSubTitulo("Novos colecionadores" )  ,  ((painel.getPreferredSize().width / 2 )  - 120)  , 50 , 300 , 30);

        JLabel l2 = posicaoTela(setFontPadrao("Nome : ")  , 30 , 120 , 500 , 30);
        JTextField t2 = posicaoTela( setCampoImput(40) , 100 , 120 , 850 , 25  );

        JLabel l3 = posicaoTela(setFontPadrao("Telefone : ")  , 30 , 170 , 500 , 30);
        JTextField t3 = posicaoTela( setCampoImput(40) , 120 , 170 , 830 , 25  );

        JLabel l4 = posicaoTela(setFontPadrao("E-mail : ")  , 30 , 220 , 500 , 30);
        JTextField t4 = posicaoTela( setCampoImput(40) , 100 , 220 , 850 , 25  );

        JLabel l5 = posicaoTela(setFontPadrao("CPF : ")  , 30 , 270 , 500 , 30);
        JTextField t5 = posicaoTela( setCampoImput(40) , 85 , 270 , 860 , 25  );

        JLabel l6 = posicaoTela(setFontPadrao("Endereço : ")  , 30 , 320 , 500 , 30);
        JTextField t6 = posicaoTela( setCampoImput(40) , 125 , 320 , 820 , 25  );

        JButton bt1 = posicaoTela(  setBtn1("Salvar novo colecionador"),  0 , 380 , ( painel.getPreferredSize().width ) , 40 ) ;

        painel.add( l1 );
        painel.add( l2 );
        painel.add( t2);
        painel.add( l3 );
        painel.add( t3);
        painel.add( l4 );
        painel.add( t4);
        painel.add( l5 );
        painel.add( t5);
        painel.add( l6 );
        painel.add( t6);
        painel.add( bt1 );

        //___________________________________________________________________________________
        bt1.addActionListener(e->{

            String [] vetor = new String[6];

            vetor[0] = t5.getText();
            vetor[1] = t2.getText();
            vetor[2] = t3.getText();
            vetor[3] = t4.getText();
            vetor[4] = t6.getText();


            String dataHoraFormatada = data.format(formato);
            vetor[5] = dataHoraFormatada ;

            boolean valida = validador. validarCampos( vetor  ) ;
            if( valida == true){

                String conteudoColborador = validador.concatenaVetor(vetor);
                String ret =  adm.setAddNovosColecionadores( conteudoColborador );
                jopAvisoSimples(ret , "Aviso" , 1);
                SwingUtilities.getWindowAncestor(painel).dispose(); // <_------------------------------

            }else{
                jopAvisoSimples("Atenção tente novamente a campos em branco" , "Aviso" , 4);
            }


        });
        //___________________________________________________________________________________

        JDialog dialog = caixaDialogo(painel ,"Adicionar Colecionador");

    }


//===========================================================================================================================

    public void editarColecionador ( String id_cole){

        Colecionadores colecionadores = new Colecionadores(id_cole);

        String[][] objColecionadorRegistrado = colecionadores .dadoLinhaColecionador(id_cole) ;

        JPanel painel = setPainel(1000 , 500 , null );
        painel.setLayout(null);
        //___________________________________________________________________________________

        JButton bt0 = posicaoTela(setBtn1("Ajuda !") ,  30  , 30 , 85 , 30);

        JLabel l1 = posicaoTela(setFontSubTitulo("Dados do colecionador" )  ,  ((painel.getPreferredSize().width / 2 )  - 120)  , 30 , 300 , 30);

        JLabel l2 = posicaoTela(setFontPadrao("Nome : ")  , 30 , 120 , 500 , 30);
        JTextField t2 = posicaoTela( setCampoImput(40 , objColecionadorRegistrado[0][1] ) , 100 , 122 , 850 , 23  );

        JLabel l3 = posicaoTela(setFontPadrao("Telefone : ")  , 30 , 170 , 500 , 30);
        JTextField t3 = posicaoTela( setCampoImput(40 , objColecionadorRegistrado[0][3]) , 120 , 172 , 830 , 23  );

        JLabel l4 = posicaoTela(setFontPadrao("E-mail : ")  , 30 , 220 , 500 , 30);
        JTextField t4 = posicaoTela( setCampoImput(40 , objColecionadorRegistrado[0][2] ) , 100 , 222 , 850 , 23 );

        JLabel l5 = posicaoTela(setFontPadrao("CPF : ")  , 30 , 270 , 500 , 30);
        JTextField t5 = posicaoTela( setCampoImput(40 , objColecionadorRegistrado[0][0]) , 85 , 272 , 860 , 23 );
        t5.setEnabled(false);

        JLabel l6 = posicaoTela(setFontPadrao("Endereço : ")  , 30 , 320 , 500 , 30);
        JTextField t6 = posicaoTela( setCampoImput(40 , objColecionadorRegistrado[0][4]) , 125 , 322 , 820 , 23  );

        JButton bt1 = posicaoTela(  setBtn1("Salvar novo colaborador"),  0 , 400 , ( painel.getPreferredSize().width  ) , 40 ) ;



        painel.add( bt0 );

        painel.add( l1 );

        painel.add( l2 );
        painel.add( t2);

        painel.add( l3 );
        painel.add( t3);

        painel.add( l4 );
        painel.add( t4);

        painel.add( l5 );
        painel.add( t5);

        painel.add( l6 );
        painel.add( t6);

        painel.add( bt1 );


        bt0.addActionListener(e->{

            jopAvisoSimples(
                    "\n\nOs campos serão preenchidos automaticamente conforme o cadastro inicial, qualquer alteração será salva, exceto o CPF, que não pode ser modificado. "+
                            "\n\nCampos vazios não serão aceitos.\n\n",
                    "Como funciona" ,
                    0
            );

        });

        bt1.addActionListener(e->{

            String dataHoraFormatada = data.format(formato);

            String [] vetor = { t5.getText()  ,  t2.getText() , t3.getText() , t4.getText() ,t6.getText() ,dataHoraFormatada };

            boolean valida = validador. validarCampos(  vetor ) ;
            if( valida == true){

                String conteudoColborador = validador.concatenaVetor( vetor );

                String ret =  colecionadores.editaDadosColecionador( conteudoColborador  , id_cole );

                jopAvisoSimples(ret , "Aviso" , 1);
                SwingUtilities.getWindowAncestor(painel).dispose();


            }else{
                jopAvisoSimples("Atenção tente novamente a campos em branco" , "Aviso" , 4);
            }

        });


        JDialog dialog = caixaDialogo(painel , "Editar contato");

    }
//===========================================================================================================================

    public  void dadosColecionador (String id_cole){

//        JOptionPane.showMessageDialog(null, id_cole , "titulo" , JOptionPane.PLAIN_MESSAGE);

        Colecionadores colecionadores = new Colecionadores(id_cole);

        JPanel painelResult = setPainel( 700 , 500 , null ) ;
        JScrollPane pResult = posicaoTela( setPainelRolagem(painelResult)  , 30 , 80 , 800 , 700 );

        try {


            String [][] result = colecionadores.getItensMeu(id_cole);


            painelResult.setPreferredSize( new Dimension( 200 , result.length * 50  ));

            for( int i = 0 ; i < result.length; i++){
            for(int j = 0 ; j < result[0].length ; j++){
                System.out.println("  + "+result[i][j]);
            }
            }

            int contPosicao = 0;

            for(int i = 0 ; i < result.length ; i++){

            JButton idColecionador = posicaoTela(
                    setBtn1("Item  : " + result[i][1] + " | Codigo : " + result[i][0]),
                    0,
                    contPosicao + i + 20,
                    800,
                    50
            );
            painelResult.add(idColecionador);
            contPosicao += 50;

            String id_Item =  result[i][0];
             idColecionador.addActionListener(r -> {
                item( id_Item );
            });

            }

        }catch ( Exception er ){

        }

        String[][] objColecionador = colecionadores.dadoLinhaColecionador( id_cole ) ;

        JPanel painel = setPainel(1600 , 800 , null );
        painel.setLayout(null);

        JLabel l1 = posicaoTela(setFontPadrao("Itens do colecionador ")  , 300 , 30 , 500 , 30);

        JSeparator s1 = posicaoTela( setSeparadorHorizontal (1800) , 880 , 0 , 50 , 1800 ) ;

        JLabel l2 = posicaoTela( setFontPadrao( "Nome : "+objColecionador[0][1]) , 900 , 70 , 600 , 50 ) ; // < --------------- nome

        JLabel l3 = posicaoTela( setFontPadrao( "E-mail : "+objColecionador[0][2]) , 900 , 120 , 600 , 50 ) ; // < --------------- email

        JLabel l4 = posicaoTela( setFontPadrao( "Telefone : "+objColecionador[0][3]) , 900 , 170 , 600 , 50 ) ; // < --------------- fone

        JLabel l5 = posicaoTela( setFontPadrao( "Endereço : "+objColecionador[0][4]) , 900 , 300 , 600 , 50 ) ; // < --------------- endereco

        JLabel l6 = posicaoTela( setFontPadrao( "Identificado : "+objColecionador[0][0]+" ( Ultima ataualização registrada "+objColecionador[0][5] + " )") ,
                900 , 210 , 600 , 100 ) ; // < --------------- endereco

        JButton nItem = posicaoTela( setBtn1("Adicionar novos itens ") , 900 , 500  , 680 , 60 );
        JButton editarCOL = posicaoTela( setBtn1("Editar dados do colecionador ") , 900 , 570 , 680 , 60 );

        painel.add(l1);
        painel.add(pResult);
        painel.add(s1);

        painel.add(l2);
        painel.add(l3);
        painel.add(l4);
        painel.add(l5);
        painel.add(l6);

        painel.add(nItem);
        painel.add(editarCOL);

        //___________________________________________________________________________________

        nItem.addActionListener(e -> {

            addItem( objColecionador[0][1], id_cole); // <-- essa função precisa adicionar ao painelResult
            SwingUtilities.getWindowAncestor(painel).dispose();
            dadosColecionador ( id_cole );

        });

        //___________________________________________________________________________________

        editarCOL.addActionListener(e -> {

            JOptionPane.showMessageDialog(null, "mensagem-ç" , "" , JOptionPane.PLAIN_MESSAGE);

            editarColecionador(id_cole);

             String[][] objColecionador2 = colecionadores.dadoLinhaColecionador(id_cole);

            l2.setText("Nome : " + objColecionador2[0][1]);
            l3.setText("E-mail : " + objColecionador2[0][2]);
            l4.setText("Telefone : " + objColecionador2[0][3]);
            l5.setText("Endereço : " + objColecionador2[0][4]);
            l6.setText("Identificado : " + objColecionador2[0][0] +
                    " ( Última atualização registrada " + objColecionador2[0][5] + " )");

            painel.revalidate();
            painel.repaint();
        });

        //___________________________________________________________________________________

        JDialog dialog = caixaDialogo(painel , "Colecionador cod "+id_cole );

    }

//===========================================================================================================================

    public void addItem(  String nomeDono , String identific ){

        JPanel painel = setPainel(660 , 700 , null );
        painel.setLayout(null);

        JLabel l1 = posicaoTela( setFontSubTitulo( "Adicionar novo item") , 200, 10 , 500 ,50);

        JLabel l2 = posicaoTela( setFontPadrao( "Nome do item : ") , 5 , 90 , 500 ,20 );
        JTextField t2 = posicaoTela( setCampoImput( 50)  , 150 , 90 , 500 ,20);

        JLabel l3 = posicaoTela( setFontPadrao( "Valor estimado : ") , 5 , 130 , 500 ,20 );
        JTextField t3 = posicaoTela( setCampoImput( 50)  , 150 , 130 , 500 ,20);

        JLabel l4 = posicaoTela( setFontPadrao( "Estado do produto : ") , 5 , 170 , 500 ,20 );
        JComboBox estado = posicaoTela(seletorString(this.estadoTipo) , 170 , 170 , 480 , 20 ) ;

        JLabel l5 = posicaoTela( setFontPadrao( "Categoria do item : ") , 5 , 210 , 500 ,20 );
        JComboBox categoria = posicaoTela(seletorString(this.categoriaTipo) , 170 , 210 , 480 , 20 ) ;

        JLabel l6 = posicaoTela( setFontPadrao( "Troca disponivel : ") , 5 , 250 , 500 ,20 );
        JComboBox troca = posicaoTela(seletorString(this.disponibilidade) , 170 , 250 , 480 , 20 ) ;


        JLabel l7 = posicaoTela( setFontPadrao( "Trocar por que : ") , 5 , 290 , 500 ,20 );
        JTextField t4 = posicaoTela( setCampoImput(50) , 170 , 290 , 480 , 20 ) ;


        JLabel l8 = posicaoTela( setFontPadrao( "Descrição do item : ") , 5 , 330 , 600 ,20 );
        JTextArea t5 = posicaoTela( setAreaTexto(5 , 5) , 5 , 370 , 650 , 200 ) ;

        JButton bt1 = posicaoTela( setBtn1("Adicionar foto do item") , 5 , 600 , 650 , 25 ) ;

        JButton bt2 = posicaoTela( setBtn1("Salvar item na coleção") , 5 , 630 , 650 , 25 ) ;


        painel.add(l1);

        painel.add(l2);
        painel.add(t2);

        painel.add(l3);
        painel.add(t3);

        painel.add(l4);
        painel.add(estado);

        painel.add(l5);
        painel.add(categoria);

        painel.add(l6);
        painel.add(troca);

        painel.add(l7);
        painel.add(t4);

        painel.add(l8);
        painel.add(t5);

        painel.add(bt1);
        painel.add(bt2);

        //__________________________________________________________________________________
        //__________________________________________________________________________________
        //__________________________________________________________________________________

        bt1.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Selecione uma imagem");
            fileChooser.setFileFilter(new FileNameExtensionFilter("Imagens", "jpg", "png", "jpeg", "gif"));

            int resultado = fileChooser.showOpenDialog(null);

            if (resultado == JFileChooser.APPROVE_OPTION) {
                imagemSelecionadaAdd = fileChooser.getSelectedFile();
                JOptionPane.showMessageDialog(null, "Imagem selecionada: " + imagemSelecionadaAdd.getName());
            }
        });

        bt2.addActionListener(e -> {

            String dataHoraFormatada = data.format(formato);
            String codi = (data.format(cod) + t2.getText().substring(0, 2)).toUpperCase();
            String v = (String) troca.getSelectedItem();

            String[] vetor = {
                    codi.toLowerCase(),
                    t2.getText(),
                    t5.getText(),
                    t3.getText(),
                    nomeDono ,
                    identific,
                    (String) categoria.getSelectedItem(),
                    (String) estado.getSelectedItem(),
                    dataHoraFormatada,
                    (String) troca.getSelectedItem(),
                    t4.getText()
            };

            boolean valida = validador.validarCampos(vetor);

            if (valida) {
                String caminhoPadraoFotoItem = "src/Pacote1/fotosItens/semImg.jpeg";

                if (imagemSelecionadaAdd != null) {
                    String codigo = codi + "_" + System.currentTimeMillis();
                    String extensao = imagemSelecionadaAdd.getName().substring(imagemSelecionadaAdd.getName().lastIndexOf("."));
                    String novoNome = codigo + extensao;

                    File destino = new File("src/Pacote1/fotosItens/" + novoNome);
                    destino.getParentFile().mkdirs();

                    try {
                        Files.copy(imagemSelecionadaAdd.toPath(), destino.toPath(), StandardCopyOption.REPLACE_EXISTING);
                        caminhoPadraoFotoItem = destino.getPath();
                        JOptionPane.showMessageDialog(null, "Imagem salva em:\n" + destino.getAbsolutePath());
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(null, "Erro ao salvar imagem: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Sem imagem adicionada ao item.");
                }

                vetor[vetor.length-1] = caminhoPadraoFotoItem;
                String conteudoConctenado = validador.concatenaVetor(vetor);

                jopAvisoSimples(conteudoConctenado, "Aviso", 1);

                Itens it = new Itens();
                String ret = it.setIten(conteudoConctenado);

//                String [][]ret =  adm.setItensColeciondors(id_item ); // <<----------------
//                Adm colecionadores = new Colecionadores(id_item);
                jopAvisoSimples( ret, "Confirmação", 1);
                SwingUtilities.getWindowAncestor(painel).dispose();
                item(  codi.toLowerCase() );

            } else {
                jopAvisoSimples("Atenção: tente novamente, há campos em branco.", "Aviso", 4);
            }
        });

        //__________________________________________________________________________________
        //__________________________________________________________________________________
        //__________________________________________________________________________________

        JDialog dialog = caixaDialogo(painel , "Adicionar itens a coleção");

    }

//===========================================================================================================================

    public void item ( String id_item ){

        Itens itens = new Itens();

        String mt [][] = itens.getDadosSelfItens(id_item) ;
        System.out.println(" >>>>>>>>>>> "+ mt[0][0]);

        JPanel painel = setPainel(1400 , 600 , null );
        painel.setLayout(null);

        //        JLabel imag =  posicaoTela(setImagPadrao("src/Pacote1/fotosItens/semImg.jpeg", 400, 400  ) , 100 , 100 , 400 , 400 );
        JLabel imag =  posicaoTela(setImagPadrao( mt[0][10] , 400, 400  ) , 100 , 100 , 400 , 400 );
        JSeparator linh1 = posicaoTela( setSeparadorHorizontal(40) , 600 , 0 ,10 , 1500  );

        JLabel l1 =  posicaoTela(setFontPadrao("Item : "+mt[0][1] ) , 620 , 30 , 700 , 50 );
        JLabel l2 =  posicaoTela(setFontPadrao("Categoria : "+mt[0][6]) , 620 , 60 , 700 , 50 );
        JLabel l3 =  posicaoTela(setFontPadrao("Estado : "+mt[0][7]) , 620 , 90 , 700 , 50 );
        JLabel l4 =  posicaoTela(setFontPadrao("Dono : "+mt[0][4]+" | identificado : "+mt[0][5] ) , 620 , 120 , 700 , 50 );
        JLabel l5 =  posicaoTela(setFontPadrao("Ultima data de atualização : "+mt[0][8]) , 620 , 150 , 700 , 50 );
        JLabel l6 =  posicaoTela(setFontPadrao("Troca : "+mt[0][9] +" | Tipo troca : "+ mt[0][3]) , 620 , 180 , 700 , 50 );
        JLabel l7 =  posicaoTela(setFontPadrao("Descrição : "+mt[0][2]) , 620 , 200 , 700 , 100 );

        JButton bt1 = posicaoTela ( setBtn1(":Trocar Item:") , 100 , 560 , 200 ,30  ) ;
        JButton bt2 = posicaoTela (setBtn1(":Editar Item: "), 310 , 560 , 200 , 30 ) ;

        painel.add(imag) ;
        painel.add(linh1) ;
        painel.add(l1) ;
        painel.add(l2) ;
        painel.add(l3) ;
        painel.add(l4) ;
        painel.add(l5) ;
        painel.add(l6) ;
        painel.add(l7) ;
        painel.add(bt1) ;
        painel.add(bt2) ;

        JDialog dialog = caixaDialogo(painel , "Item codigo "+id_item);

    }

//===========================================================================================================================

    public void editarTrocarItem ( String item ){
        JPanel painel = setPainel(1400 , 600 , null );
        painel.setLayout(null);
        //__________________________________________________________________________________



        //__________________________________________________________________________________
        JDialog dialog = caixaDialogo(painel ,  item );

    }

// ===========================================================================================================================

    private JDialog caixaDialogo(JPanel painel, String titulo) {
        JDialog dialog = new JDialog();
        dialog.setTitle(titulo);
        dialog.setContentPane(painel);
        dialog.pack(); // ou dialog.setSize(1600, 800);

        dialog.setResizable(false); // Impede que o usuário redimensione a janela

        dialog.setLocationRelativeTo(null);
        dialog.setModal(true);
        dialog.setVisible(true);
        return dialog;
    }


}
