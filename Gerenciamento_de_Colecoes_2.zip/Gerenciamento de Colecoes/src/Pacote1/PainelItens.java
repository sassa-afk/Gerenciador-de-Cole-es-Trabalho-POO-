package Pacote1;

import javax.swing.*;
import java.awt.*;

public class PainelItens extends Componentes{

    private JPanel painel ;

    PainelItens (int width  , int heigth  , Color cor ){
        this.painel = setPainel( width , heigth , cor );
    }
    public JPanel setPainel(){

        JLabel l1 = posicaoTela( setFontSubTitulo("Itens Registrados") , 30 , 45 , 300 , 50);

        JButton ajuda = posicaoTela( setBtn1("Duvidas")  , 1220 , 30 , 100 , 25);

        String [] vetor1 = {
                "Ver todos itens" ,
                "Filtrar itens pela epecificação do item" ,
                "Filtrar itens pela especificação do colecionador",
                "Filtrar itens pela categoria do item"
        };
        JComboBox filtroItens =  posicaoTela( seletorString (vetor1) , 30 , 120 ,  1300 , 30 );

        String [] vetor2 = {
                "Filtrar por itens indisponiveis e disponiveis para troca" ,
                "Filtrar por itens disponiveis para troca" ,
                "Filtrar por itens indisponiveis para troca"
        };
        JComboBox filtroDisponibilidade =  posicaoTela( seletorString (vetor2) , 30 , 160 ,  1300 , 30 );

        JTextField dadosFIltro = posicaoTela( setCampoImput(20), 30 , 200 ,  1300 , 30 );
        dadosFIltro.setToolTipText("Este campo não se aplica se você utilizar a função 'Ver todos itens' no primeiro filtro ");

        JButton buscar = posicaoTela( setBtn1("Buscar itens") , 30 , 240 ,  1300 , 30);

        JSeparator linha1 =  posicaoTela( setSeparador(), 0 , 300 , 1600 , 10 ) ;

         JScrollPane p1PesquisaScroll = posicaoTela (
                 setPainelRolagem(
                         setPainel(
                                 1250 , 600 , new Color(204, 217, 230, 255) // <---- controla tamanho jpanel
                         )
                 ) , 30 , 340 , 1300 , 550
         );

        painel.add(l1);
        painel.add(ajuda);
        painel.add(filtroItens);
        painel.add(filtroDisponibilidade);
        painel.add(dadosFIltro);
        painel.add(buscar);
        painel.add(linha1);
        painel.add(p1PesquisaScroll);
        // --------------------------------------
        ajuda.addActionListener( a ->{
            String respostaDuvida =
                    "Informações sobre os campos de filtro de itens:\n\n" +
                            "1 - Será possível filtrar apenas o item especificando o nome ou ID registrado.\n\n" +
                            "2 - Será possível filtrar itens de um colecionador especifico, utilizando seu registro de nome ou identificador .\n\n" +
                            "3 - Será possível filtrar itens apenas pelas categorias registradas.";



            jopAvisoSimples( respostaDuvida , "Duvidas" , 3 );
        });
        // --------------------------------------
        return this.painel ;
    }


//    private < T extends JComponent > T  setPosicao ( T  item ,   int x , int  y , int  largura , int altura  ){
//        item.setBounds( x , y , largura , altura) ;
//        return item ;
//    }


}
