package Pacote1;

public class Itens extends  Colecionadores {



    //-------------------------------  Itens  ------------------------------------

    // Self dados itens
    protected  String[][] dadoLinhaColecionador (String dadoPesquisa){
        return  getLinhasComIndex( getFileItens() , dadoPesquisa  );
    }
    protected   String [][] getDadosSelfItens ( String dados ){
        return dadoLinhaColecionador (dados) ;
     }






}
