package Pacote1;

import javax.swing.*;
import java.awt.*;


public class PainelColecionadores extends Componentes{
    JanelasJOP jopPaineis = new JanelasJOP();
    Adm adm = new Adm();
    public JPanel painel ;

    PainelColecionadores (int width  , int heigth  , Color cor ){
        this.painel = setPainel( width , heigth , cor );
     }

     public JPanel setPainel(){

        JLabel l1 = posicaoTela(setFontSubTitulo("Painel do colecionador"), 30 , 40 , 300 , 50  );

        String [] opFIltro = {
                "Filtrar todos colecionadores" ,
                "Filtrar colecionador por Nome ou CPF"
        } ;


        JComboBox tipoFiltro = posicaoTela( seletorString(opFIltro) , 30 , 120 ,  1300 , 30 );

         JTextField dadosFiltro = posicaoTela(  setCampoImput(20) , 30 , 170 ,  1300 , 30  ) ;
         dadosFiltro.setToolTipText(
                 "Campo aplicavel apenas para filtros por nome ou identificador"
         );

        JButton buscar = posicaoTela(setBtn1("Aplicar Filtro Avançado" ),30 , 220 , 1300 , 30  );

        JSeparator linha1 = posicaoTela(setSeparador() , 0 , 280 , 1800 , 10  );

        JButton novoColecionador = posicaoTela( setBtn1("Adicionar Colecionador" ) , 30 , 295 , 200 , 30  );

        JPanel pesquisa = setPainel( 200 , 500 , new Color(204, 217, 230, 255) ) ; //  valor 1000 e height ira decidir tamanho da rolagem , aqui aplicar metodo comptivel tamano da rolagem
        JScrollPane  p1PesquisaScroll = setPainelRolagem(pesquisa);
        p1PesquisaScroll.setBounds(30 , 350 , 1300 , 500 );

        this.painel.add(l1);
        this.painel.add(tipoFiltro);
        this.painel.add(dadosFiltro);
        this.painel.add(buscar);
        this.painel.add(linha1);
        this.painel.add(novoColecionador);
        this.painel.add(p1PesquisaScroll);

        acao( novoColecionador , buscar , pesquisa , tipoFiltro, dadosFiltro   ) ;

        return this.painel ;
    }

//    private < T extends JComponent > T posicaoTela ( T componente , int x , int y , int largura  , int  altura  ) {
//        componente.setBounds(x, y, largura , altura );
//        return componente;
//    }


    private void acao (JButton add , JButton busca , JPanel painel ,  JComboBox valorTipoFiltro , JTextField DadosFiltro ){

        //        ************************ 1
        add.addActionListener( e->{

            jopPaineis.novoColecionador();

        });
        //        ************************ 2
        busca.addActionListener(e -> {

            String valorSelecionado = (String) valorTipoFiltro.getSelectedItem();
            String valorDadosFiltro = DadosFiltro.getText();

            painel.removeAll();

            if (valorSelecionado.trim().equals("Filtrar todos colecionadores")) {

                String[][] matriz = adm.getColecinadores();
                int contPosicao = 0;

                painel.setPreferredSize( new Dimension( 200 , matriz.length * 45  ));

                try{

                    for (int i = 0; i < matriz.length; i++) {

                        JLabel idColecionador = posicaoTela(
                                setFontPadrao((i + 1) + " - CPF : " + matriz[i][0] + " | Nome : " + matriz[i][1]),
                                20,
                                contPosicao + i + 5,
                                1170,
                                50
                        );

                        JButton btnAcess = posicaoTela(setBtn1("Acessar"),
                                1170,
                                contPosicao + i + 5,
                                100,
                                30
                        );

                        painel.add(idColecionador);
                        painel.add(btnAcess);

                        String cpf = matriz[i][0]; // captura segura para lambda
                        btnAcess.addActionListener(r -> {
                            jopPaineis.dadosColecionador(cpf);
                        });

                        contPosicao += 40;
                    }



                }
                catch ( Exception err ){
                    JLabel idColecionador = posicaoTela(
                            setFontPadrao("Pesquisa sem informações"),
                            20,
                            5,
                            1170,
                            50
                    );
                    painel.add(idColecionador);

                }
            }
            else if( valorSelecionado.trim().equals("Filtrar colecionador por Nome ou CPF")
                    &&  !valorDadosFiltro.isEmpty() ){

                String[][] matriz = adm.getColecinadores( valorDadosFiltro );

                int contPosicao = 0;

                painel.setPreferredSize( new Dimension( 200 , matriz.length * 45  ));

                try{

                    for (int i = 0; i < matriz.length; i++) {

                        JLabel idColecionador = posicaoTela(
                                setFontPadrao((i + 1) + " - CPF : " + matriz[i][0] + " | Nome : " + matriz[i][1]),
                                20,
                                contPosicao + i + 5,
                                1170,
                                50
                        );

                        JButton btnAcess = posicaoTela(setBtn1("Acessar"),
                                1170,
                                contPosicao + i + 5,
                                100,
                                30
                        );

                        painel.add(idColecionador);
                        painel.add(btnAcess);

                        String cpf = matriz[i][0]; // captura segura para lambda
                        btnAcess.addActionListener(r -> {
                            jopPaineis.dadosColecionador(cpf);
                        });

                        contPosicao += 40;
                    }



                }
                catch ( Exception err ){
                    JLabel idColecionador = posicaoTela(
                            setFontPadrao("Pesquisa sem informações"),
                            20,
                            5,
                            1170,
                            50
                    );
                    painel.add(idColecionador);

                }
            }
            else{
                JLabel idColecionador = posicaoTela(
                        setFontPadrao("Pesquisa sem informações"),
                        20,
                        5,
                        1100,
                        50
                );
                painel.add(idColecionador);
            }

            painel.repaint();
            painel.revalidate();

        });
        //        ************************

    }

    @Override
    public JButton setBtn1(String descricao){
        return setBasicoBotao( descricao ,new Color(51, 95, 136, 40) );
    }


}
