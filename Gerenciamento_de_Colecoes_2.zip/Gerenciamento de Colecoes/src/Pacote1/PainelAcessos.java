package Pacote1;

import javax.swing.*;
import java.awt.*;

public class PainelAcessos extends  Componentes {

    private JPanel painel ;
    PainelAcessos (int width  , int heigth  , Color cor ){
        this.painel = setPainel( width , heigth , cor );
    }

    public JPanel setPainel(){


        return this.painel ;
    }


}
