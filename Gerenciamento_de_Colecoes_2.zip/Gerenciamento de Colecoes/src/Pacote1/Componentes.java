package Pacote1;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;

abstract class Componentes {

    // ========================  Frames e Painel  ========================

    public JFrame janela (int width , int height , String titulo , boolean redimensaoJanela ) {
        JFrame janela = new JFrame(titulo) ;
        janela.setSize( width , height );
        janela.setResizable(redimensaoJanela);
        janela.setVisible(true);

        return janela ;
    }

    public JPanel setPainel (int width , int height , Color cor ){
        JPanel painel = new JPanel();
        painel.setPreferredSize( new Dimension( width , height  ));
        painel.setBackground(cor);
        painel.setLayout(null);
        return painel ;
    }

    public JScrollPane setPainelRolagem (JPanel painel ){
        JScrollPane pRolagem = new JScrollPane(painel);
        pRolagem.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        pRolagem.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        return pRolagem ;
    }

    // ========================  Label  ========================

    protected JLabel  setLabel ( String texto , int tamanho_font , Color cor ){
        JLabel label = new JLabel(texto);
        Font font = label.getFont().deriveFont(Font.BOLD , tamanho_font );
        label.setFont(font);
        label.setForeground(cor);
        return label ;
    }

    public JLabel setFontPadrao(String texto){
        return setLabel( texto , 15 , Color.BLACK );
    }

    public JLabel setFontTitulo ( String texto ) {
        return setLabel( texto , 35 , Color.BLACK ) ;
    }

    public JLabel setFontSubTitulo ( String texto ) {
        return setLabel( texto , 20 , Color.BLACK ) ;
    }

    // ========================  Label image  ========================

     public JLabel setImagPadrao (String caminhoImg , int width , int heigth ){
        ImageIcon img1 = new ImageIcon(caminhoImg);
        Image imgDimenciona = img1.getImage().getScaledInstance(width , heigth , Image.SCALE_SMOOTH);
        ImageIcon img2 = new ImageIcon(imgDimenciona);
        JLabel labelImg = new JLabel();
        labelImg.setIcon(img2);
        return labelImg ;
     }

    //  ========================  Imputs  ========================

    public JTextField setCampoImput ( int tamanho){
        return new JTextField(tamanho) ;
    }

    public JTextField setCampoImput ( int tamanho , String valor ){
        return new JTextField( valor , tamanho) ;
    }


    public JPasswordField setImputSenha (int tamanho){
        return  new JPasswordField(tamanho);
    }

    public JTextArea setAreaTexto (int row , int column){
        JTextArea area = new JTextArea( row , column );
        area.setLineWrap(true);
        area.setLineWrap(true);
        return area ;
    }

    public JComboBox seletorNumerico (int [] opcoes_numerica){
        Integer [] opcao = new Integer[opcoes_numerica.length];
        JComboBox<Integer> comboBox = new JComboBox<>(opcao) ;
        return comboBox ;
    }

    public JComboBox seletorString ( String [] opcaoes_str ){
        String [] opc = new String[opcaoes_str.length] ;
         JComboBox<String> comboBox = new JComboBox<>(opcaoes_str);
        return comboBox ;
    }

    //  ========================  Botão  ========================

    protected JButton setBasicoBotao( String descricao , Color cor ){
        JButton btn = new JButton(descricao);
//        btn.setBackground(cor);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setFocusable(false);
        return btn ;
    }

    public JButton setBtn1(String descricao){
        return setBasicoBotao( descricao , new Color(209, 204, 204, 255) );
    }
//new Color(209, 204, 204, 255
    //  ========================  Separador  ========================

    public JSeparator setSeparador() {
        JSeparator separador = new JSeparator();
        separador.setPreferredSize(new Dimension(500, 5));
        return separador;
    }

    public JSeparator setSeparadorHorizontal(int tamanho ) {
        JSeparator separador = new JSeparator(SwingConstants.VERTICAL);
        separador.setPreferredSize(new Dimension(tamanho, 700)); // Largura 500, altura 5
        return separador;
    }

    //  ========================  aviso JPanel  ========================

    public final void jopAvisoSimples (String mensagem , String titulo , int tipo ){

        if( tipo == 1){ //  aviso
            JOptionPane.showMessageDialog(null, mensagem , titulo, JOptionPane.INFORMATION_MESSAGE);
        }
        else if( tipo == 2 ){ // atenção
            JOptionPane.showMessageDialog(null, mensagem , titulo, JOptionPane.WARNING_MESSAGE);
        }
        else if( tipo == 3 ){ // duvida - confirmação
            JOptionPane.showMessageDialog(null, mensagem , titulo, JOptionPane.QUESTION_MESSAGE);
        }

        else if( tipo == 4 ){ // ERROR
            JOptionPane.showMessageDialog(null, mensagem , titulo, JOptionPane.ERROR_MESSAGE);
        }
        else if( tipo == 0 ){ // sem dialogo
            JOptionPane.showMessageDialog(null, mensagem , titulo , JOptionPane.PLAIN_MESSAGE);
        }
    }

    //  ========================  JPanel painel extra  ========================

    public  < T extends JComponent > T posicaoTela ( T componente , int x , int y , int largura  , int  altura  ) {
        componente.setBounds(x, y, largura , altura );
        return componente;
    }



}
