package Pacote1;

import javax.swing.*;
import java.awt.*;

public class Login extends  Componentes {
    public JFrame getLogin (){
        JFrame janela = janela(1300 , 800 , "Painel de login" , false );
        JPanel painel = setPainel(1300 , 800 , new Color(195, 149, 59, 155)  );

        int espacamentoComponentes = 820 ;

        //  ==============================================

        JLabel img = posicaoTela (  setImagPadrao("src/Pacote1/fotoSistema/img1.jpg" ,700 ,1300 ) , 0 , 0, 800 ,1300  ) ;

        JLabel l1 = posicaoTela (setFontTitulo("Gerenciador de itens" ) , espacamentoComponentes , 210, 500 ,100 );

        JLabel l2 = posicaoTela ( setFontPadrao ("Usuário :" ) , espacamentoComponentes , 300 , 400  , 30 ) ;

        JTextField imp1 = posicaoTela( setCampoImput(15) , espacamentoComponentes , 330, 400 ,30  ) ;

        JLabel l3 =  posicaoTela ( setFontPadrao("Senha :" ) , espacamentoComponentes , 370 , 400  , 30 ) ;

        JPasswordField imp2 = posicaoTela ( setImputSenha(5) , espacamentoComponentes , 400 , 400 ,30 ) ;

        JButton btn = posicaoTela( setBtn1("Logar") , espacamentoComponentes , 450 , 400 , 50 );

        //  ==============================================
        painel.add(img);
        painel.add(l1);
        painel.add(l2);
        painel.add(imp1);
        painel.add(l3);
        painel.add(imp2);
        painel.add(btn);
        janela.add(painel);
        //  ==============================================

        acessar(btn , imp1 , imp2 );

        return janela ;

    }


    private void acessar ( JButton  btn , JTextField imp1 , JPasswordField imp2 ){

        btn.addActionListener( e-> {

            String user  = imp1.getText();
            char [] senhaChar = imp2.getPassword();
            String senha = new String(senhaChar);

            if( user.isEmpty() || senha.isEmpty() ){
                jopAvisoSimples ("Campos de usuário ou senha em branco" , null , 4 ) ;
            }else {
                Adm adm = new Adm();
                boolean retornoAcesso = adm.authAdm( user , senha );

                if( retornoAcesso == true ){
                    Main main = new Main ();
                    main.getConfirmaAcesso(user);
                }else {
                    jopAvisoSimples ( "Usuário ou senha incorretos" , "Erro de autenticação" , 4 ) ;
                }
            }
        });

    }

}
