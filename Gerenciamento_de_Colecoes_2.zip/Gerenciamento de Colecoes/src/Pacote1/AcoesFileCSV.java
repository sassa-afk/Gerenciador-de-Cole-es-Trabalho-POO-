package Pacote1;
import java.io.*;
import java.util.*;

abstract  class AcoesFileCSV {

    private String fileAcessos = "src/Pacote1/file.csv";
    private String fileColecionadores = "src/Pacote1/file2.csv";
    private String fileItens = "src/Pacote1/itens.csv";

//--------------------------------------------------------------------------------------------
    //    ****************************************************** obter camino dos arquivos

    protected String getFileAcessos(){
        return this.fileAcessos ;
    }

    protected String getFileColecionadores(){
        return this.fileColecionadores ;
    }

    protected String getFileItens(){
        return this.fileItens ;
    }


    //    ****************************************************** para consulta e add geral

    protected String[][] getConteudoCompletoFile(String file) {
        try (BufferedReader leitor = new BufferedReader(new FileReader(file))) {
            String linha;
            List<String[]> linhas = new ArrayList<>();

            while ((linha = leitor.readLine()) != null) {
                linhas.add(linha.split(";"));
            }
            if (linhas.isEmpty()) {
                return new String[][] { { "pesquisa sem dados" } };
            }

            int colunas = linhas.get(0).length;
            String[][] matriz = new String[linhas.size()][colunas];

            for (int i = 0; i < linhas.size(); i++) {
                matriz[i] = linhas.get(i);
            }

            return matriz;
        } catch (Exception e) {
            System.err.println(e.getMessage());
             return new String[][] { {  e.getMessage() } };

        }
    }

    protected String setDadosFile(String file, String conteudo) {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(file, true))) {
            escritor.write(conteudo);
            escritor.newLine();
            return "Dado adicionado com sucesso";
        } catch (IOException e) {
//            System.err.println("Erro ao adicionar conteúdo: " + e.getMessage());
            return  "Erro ao adicionar conteúdo: " + e.getMessage() ;
        }
    }



//    ****************************************************** para consulta linha , atualizar , remover linha especifica

protected String setAtualizarDadoLinha(String file, String index, String novaLinhaCompleta) {
    try {
        List<String> linhas = new ArrayList<>();
        boolean editado = false;

        try (BufferedReader leitor = new BufferedReader(new FileReader(file))) {
            String linha;
            while ((linha = leitor.readLine()) != null) {

                if (linha.contains(index) && !editado) {

                    if(novaLinhaCompleta.equals("delet")){
                        editado = true;
                        continue;
                    }else {
                        linha = novaLinhaCompleta;
                        editado = true;
                    }

                }
                linhas.add(linha);
            }
        }

        if (editado) {
            try (BufferedWriter escritor = new BufferedWriter(new FileWriter(file))) {
                for (String linha : linhas) {
                    escritor.write(linha);
                    escritor.newLine();
                }
            }
            return "Dados atualizada com sucesso.";
        } else {
            return "Informação não encontrada";
        }

    } catch (Exception e) {
        return "Erro ao editar o arquivo";
    }
}

protected String[][] getLinhasComIndex(String file, String index) {
    try (BufferedReader leitor = new BufferedReader(new FileReader(file))) {
        String linha;
        List<String[]> resultados = new ArrayList<>();

        while ((linha = leitor.readLine()) != null) {
            if (linha.contains(index)) {
                resultados.add(linha.split(";"));
            }
        }

        if (resultados.isEmpty()) {
            return new String[][]{{"Informação não encontrada"}};
        }

        return resultados.toArray(new String[0][]);
    } catch (Exception e) {
        return new String[][]{{"Erro ao ler o arquivo"}};
    }
}

//    ****************************************************** peculiaridades nao usual , ate o momento

    protected boolean getDadoExisteColunaEspecifica(String file, String index, int colunaAlvo) {
    try (BufferedReader leitor = new BufferedReader(new FileReader(file))) {
        String linha;

        while ((linha = leitor.readLine()) != null) {
            String[] partes = linha.split(";");
            if (colunaAlvo >= 0 && colunaAlvo < partes.length) {
                if (partes[colunaAlvo].equals(index)) {
                    return true;
                }
            }
        }
        return false;

    } catch (Exception er) {
        return false;
    }
}

    protected String setAtualizarDadosPosicaoEspecifica(String file, String index, int colunaAlvo, String novoValor) {
        try {
            List<String> linhas = new ArrayList<>();
            boolean editado = false;

            try (BufferedReader leitor = new BufferedReader(new FileReader(file))) {
                String linha;
                while ((linha = leitor.readLine()) != null) {
                    if (linha.contains(index) && !editado) {
                        String[] partes = linha.split(";");
                        if (colunaAlvo >= 0 && colunaAlvo < partes.length) {
                            partes[colunaAlvo] = novoValor;
                            linha = String.join(";", partes);
                            editado = true;
                        }
                    }
                    linhas.add(linha);
                }
            }

            if (editado) {
                try (BufferedWriter escritor = new BufferedWriter(new FileWriter(file))) {
                    for (String linha : linhas) {
                        escritor.write(linha);
                        escritor.newLine();
                    }
                }
                return "Dado atualizado com sucesso.";
            } else {
                return "Informação não encontrada ou índice inválido";
            }

        } catch (Exception e) {
            return "Erro ao editar o arquivo";
        }
    }
}
