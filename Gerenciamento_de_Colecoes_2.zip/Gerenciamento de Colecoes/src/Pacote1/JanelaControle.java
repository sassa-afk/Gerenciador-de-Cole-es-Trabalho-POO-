package Pacote1;

import javax.swing.*;
import java.awt.*;


public class JanelaControle extends  Componentes {

    private int larguraPanel = 1600 ;
    private int alturaPanel = 950 ;
    private Color corPadraoPanel =  new Color(204, 217, 230, 255)   ;

//    private Color corPadraoPanel =  new Color(209, 204, 204, 255)    ;
//    private Color corPadraoPanel =  new Color(107, 168, 227, 255)  ;

    private  JPanel p1 =  new PainelColecionadores( larguraPanel , alturaPanel , corPadraoPanel ).setPainel();

    private  JPanel p2  = new PainelItens(larguraPanel , alturaPanel , corPadraoPanel ).setPainel() ;

    private JPanel  p3 = new PainelAcessos(larguraPanel , alturaPanel , corPadraoPanel ).setPainel();

    public JFrame janelaControle (){

        JFrame janela = janela(1600 , 950 , "Painel de controle" , false );
        janela.setLayout(null);

        // ===========================================

         JPanel menu = posicaoTela( setPainel( 1600 , 950 ,new Color(107, 168, 227, 255) ), 0 , 0 , 250 , 950 );

        JLabel icon_1 =  posicaoTela ( setImagPadrao("src/Pacote1/fotoSistema/icon_perfil.png" , 250 , 250 ) , 0 , 30 , 250 , 250 );

        JButton btn1 = posicaoTela( setBtn1("Colecionadores") , 0 , 300 , 250 , 50  );

        JButton btn2 = posicaoTela( setBtn1("Itens") , 0 , 350 , 250 , 50 ) ;

        JButton btn3 = posicaoTela( setBtn1("Acessos") , 0 , 400 , 250 , 50  ) ;

        JButton btn4 = posicaoTela( setBtn1("Sair") , 0 , 450 , 250 , 50  );

        menu.add(icon_1);
        menu.add(btn1);
        menu.add(btn2);
        menu.add(btn3);
        menu.add(btn4);
        // ===========================================

        janela.add(menu);
        acaoesBotoes( btn1 , btn2 , btn3 , btn4 , janela ) ;

        return janela ;
    }

    private void acaoesBotoes ( JButton bt1 , JButton bt2 , JButton bt3  , JButton bt4 , JFrame janela )    {

        p1.setBounds(250 , 0 , this.larguraPanel , this.alturaPanel );
        p2.setBounds(250 , 0 , this.larguraPanel , this.alturaPanel );
        p3.setBounds(250 , 0 , this.larguraPanel , this.alturaPanel );

        janela.add(p1);

        bt1.addActionListener( e ->{

            removePaineis(janela);
            janela.add(p1);
            janela.revalidate();
            janela.repaint();

        });

        bt2.addActionListener(e -> {
            removePaineis(janela);
            janela.add(p2);
            janela.revalidate();
            janela.repaint();
        });

        bt3.addActionListener( e ->{
            removePaineis(janela);
            janela.add(p3);
            janela.revalidate();
            janela.repaint();

        });

        bt4.addActionListener( e ->{
            jopAvisoSimples("Aplicação encerrada" , ""  , 1);
            System.exit(0);
        });



    }

    private void removePaineis ( JFrame janela  ) {
        janela.remove(p1);
        janela.remove(p2);
        janela.remove(p3);
    }

//    private < T extends JComponent > T posicaoTela ( T componente , int x , int y , int largura  , int  altura  ) {
//        componente.setBounds(x, y, largura , altura );
//        return componente;
//    }

}