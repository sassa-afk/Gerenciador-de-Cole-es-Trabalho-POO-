package Pacote1;

public class FuncaoGeral {

    public boolean validarCampos (String [] dados){

        for(int i = 0 ; i < dados.length ; i++){
            if( dados[i].isEmpty() || dados[i] == null || dados[i].equals(" ") ){
                return false ;
            }
        }
        return true ;
    }

    public String concatenaVetor(String [] vetor ){

        try{
            String p_fim = "";
            for(int i = 0 ; i < vetor.length ; i++){
                p_fim = p_fim + vetor[i]+";" ;
            }
            return p_fim.substring( 0 , (p_fim.length() - 1) ) ;

        }catch ( Exception e ){
            return "" ;

        }
    }


}
