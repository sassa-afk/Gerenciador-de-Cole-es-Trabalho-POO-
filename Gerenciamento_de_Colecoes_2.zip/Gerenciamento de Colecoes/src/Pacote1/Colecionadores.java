package Pacote1;

public class Colecionadores extends Adm {

    private String idCole ;

    Colecionadores(){}
    Colecionadores (String id_cpf){
        this.idCole = id_cpf ;
    }


    //-------------------------------  COLECIONADORES  ------------------------------------
    // PODE VER  E EDITAR INFORMAÇÕES DE SE MESMO

    // List Self
    protected  String[][] dadoLinhaColecionador (String dadoPesquisa){
        return  super.getLinhasComIndex( getFileColecionadores() , dadoPesquisa  );
     }
     // Edit self
    protected  String editaDadosColecionador ( String novoConteudo , String id_Identificador) {
        return setAtualizarDadoLinha( getFileColecionadores(), id_Identificador, novoConteudo);
     }

    //-------------------------------  ITENS  ------------------------------------

    // ADD ITENS PARA SE ---
    protected String setAddNovosColecionadores( String dados ){
        String retorno = setDadosFile( getFileItens() , dados ) ;
        return retorno ;
    }
    protected String setIten( String dadosArmazenado ){
        return setAddNovosColecionadores(dadosArmazenado) ;
    }

    // VER TODOS ITENS DE ACESSO Colecionador ---
    protected String [][] getColecinadores ( String dados ) {
        try{
            String [][] consulta = getLinhasComIndex( getFileItens() , dados);
            return consulta ;

        }catch (Exception err){
            return new String[][] {{"Erro de formatação do arquivo "+err}};
        }
    }
    protected String [][] getItensMeu ( String dados) {
        return getColecinadores(dados);
    }





// ========================






}